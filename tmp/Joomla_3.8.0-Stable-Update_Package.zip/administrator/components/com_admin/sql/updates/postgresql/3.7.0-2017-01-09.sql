-- Normalize categories table default values.
ALTER TABLE "#__categories" ALTER COLUMN "title" SET DEFAULT '';
ALTER TABLE "#__categories" ALTER COLUMN "params" SET DEFAULT '';
ALTER TABLE "#__categories" ALTER COLUMN "metadesc" SET DEFAULT '';
ALTER TABLE "#__categories" ALTER COLUMN "metakey" SET DEFAULT '';
ALTER TABLE "#__categories" ALTER COLUMN "metadata" SET DEFAULT '';
